package hu.hobbijava.ocr_cam_lotto.controler;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class TalalatEll {

    private TalalatEll() {
    }

    public static Map talalatEll(List<List<Integer>> nyeroszamok, List<List<Integer>> szelveny) {

        Map result;
        result = new LinkedHashMap<Integer, Integer>();
        for (int i = 4; i < 8; i++) {
            result.put(i, 0);

        }

        int talalat;

        for (List<Integer> egySorTipp : szelveny) {

            for (List<Integer> egySorNyeroszam : nyeroszamok) {
                talalat = 0;
                for (int kihuzottSzam : egySorNyeroszam) {
                    if (egySorTipp.contains(kihuzottSzam)) {
                        talalat++;
                    }
                }
                if (talalat > 3) {
                    int oldTalalatSzam = (int) result.get(talalat);
                    int customTalalatSzam = oldTalalatSzam + 1;
                    result.replace(talalat, customTalalatSzam);

                }
            }

        }
        return result;
    }




}
