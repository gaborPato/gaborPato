package hu.hobbijava.ocr_cam_lotto.view

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.androidmads.ocrcamera.R
import kotlinx.android.synthetic.main.activity_talalat_result.*

class TalalatResultActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_talalat_result)
        talalat_result_tv.setText(intent.getStringExtra("result"))
    }
}
