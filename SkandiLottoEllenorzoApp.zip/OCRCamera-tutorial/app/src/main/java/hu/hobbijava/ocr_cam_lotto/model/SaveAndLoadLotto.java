package hu.hobbijava.ocr_cam_lotto.model;

import android.os.Environment;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SaveAndLoadLotto {
    private SaveAndLoadLotto(){}

    private static RandomAccessFile raf;
    private static File filepath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
    private static File lottoFile = new File(filepath,"mylotto.txt");

    public static  void  saveLotto(String textNumber) throws IOException {

        lottoFile.delete();
        lottoFile.createNewFile();
        raf= new RandomAccessFile(lottoFile,"rw");


        raf.seek(0);
        raf.writeBytes(textNumber);
        if(raf != null) raf.close();
    }

    public static List<List<Integer>> loadLotto() throws Throwable {

        raf= new RandomAccessFile(lottoFile, "r");
        raf.seek(0);

        List<List<Integer>> result= new ArrayList<>();

        String line;

        while(true){

            line=raf.readLine();
            if(line== null) break;

            String[] split = line.split(" ");

            Integer[] aLineNumber= new Integer[split.length];
            for (int i = 0; i < aLineNumber.length; i++) {
                try {
                    aLineNumber[i]= Integer.parseInt(split[i]);
                }catch (NumberFormatException n){
                    Throwable t = new Throwable(n.getMessage());
                    throw t;
                }


            }


            List<Integer> aLine= new ArrayList(Arrays.asList(aLineNumber));
            if(aLine.size() != 7){
                throw new Exception("nem 7 szám van");
            }
            result.add(aLine);
        }
        if(raf != null){
            raf.close();
        }

        return result;


    }

    public static List<List<Integer>> createLottedList(String [] huzasok) throws Throwable {
        List<List<Integer>> result= new ArrayList<>();
        for (String huzas : huzasok) {

            String[] split = huzas.split("/");

            Integer [] aLineNumbers= new Integer[split.length];
            for (int i = 0; i < aLineNumbers.length; i++) {
                try {
                    aLineNumbers[i] = Integer.parseInt(split[i]);
                }catch (NumberFormatException e){
                    Throwable t = new Throwable(e.getMessage());

                    throw t;
                }

            }
            List<Integer> aLine= new ArrayList(Arrays.asList(aLineNumbers));
            if(aLine.size() != 7){
                throw new Exception("nem 7 szám van");
            }

            result.add(aLine);

        }

        return result;
    }

}
