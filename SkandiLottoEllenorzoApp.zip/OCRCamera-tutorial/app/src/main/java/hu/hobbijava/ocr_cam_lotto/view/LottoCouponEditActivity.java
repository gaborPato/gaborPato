package hu.hobbijava.ocr_cam_lotto.view;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

import com.androidmads.ocrcamera.R;

public class LottoCouponEditActivity extends AppCompatActivity {

    private EditText readLottoEditText;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read_edit_lotto);
        readLottoEditText= findViewById(R.id.read_lotto_editText);
        Intent intent = getIntent();
        //intent.getStringExtra("read");
        readLottoEditText.setText(intent.getStringExtra("read"));
    }

    public void onclick(View view) {

        Intent i = new Intent();
        i.putExtra("edit",readLottoEditText.getText().toString());
        setResult(RESULT_OK,i);
        finish();
    }
}
