package hu.hobbijava.ocr_cam_lotto.controler;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class TalalatMap extends LinkedHashMap {

    @Override
    public String toString() {

        String result="";
        Set<Integer> set = this.keySet();
        List<Integer> keysArrayList= new ArrayList<>(set);
        for (int i= 0 ; i<this.size();i++){
            Integer value = (Integer) this.get(i+keysArrayList.get(0));
            result+= keysArrayList.get(i)+" találat: "+value +"\n";


        }
        return result;

    }
}
